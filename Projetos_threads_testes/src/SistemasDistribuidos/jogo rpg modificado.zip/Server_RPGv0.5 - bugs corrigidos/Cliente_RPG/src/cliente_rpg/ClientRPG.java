/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente_rpg;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jogo.Acao;
import jogo.Personagem;
import util.Mensagem;
import util.Status;

/**
 *
 * @author elder
 */
public class ClientRPG {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        try {
            /*
             1. Estabelecer conexão com o servidor
             2. Trocar mensagens com o servidor
             */
            //cria a conexão entre o cliente e o servvidor
            System.out.println("Estabelecendo conexão...");
            Socket socket = new Socket("localhost", 5555);
            System.out.println("Conexão estabelecida.");

            //criação dos streams de entrada e saída
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
            System.out.println("Enviando mensagem...");
            /*protocolo
             HELLO
             nome : String
             sobrenome: String
            
             HELLOREPLY
             OK, ERRO, PARAMERROR
             mensagem : String
            
             */

            Personagem p = new Personagem();

            String nome = JOptionPane.showInputDialog("Informe o nome");
            Double ataque = Double.parseDouble(JOptionPane.showInputDialog("Informe o ataque"));
            Double defesa = Double.parseDouble(JOptionPane.showInputDialog("Informe o defesa"));
            Double vida = Double.parseDouble(JOptionPane.showInputDialog("Informe o vida"));
            Double cura = Double.parseDouble(JOptionPane.showInputDialog("Informe o cura"));

            p.setNome(nome);
            p.setAtaque(ataque);
            p.setCura(cura);
            p.setDefesa(defesa);
            p.setVida(vida);

            Mensagem m = new Mensagem("ENTRARNOJOGO");
            m.setParam("personagem", p);

            output.writeObject(m);
            output.flush();

            m = (Mensagem) input.readObject();
            System.out.println("Resposta: " + m);
            
            if(m.getParam("id").toString() == null){
                JOptionPane.showMessageDialog(null, "nulo");
            }else{
                p.setId(Integer.parseInt(m.getParam("id").toString()));
            }
            
            JOptionPane.showMessageDialog(null, m.getParam("id"));

            boolean sair = false;
            while (!sair) {
                JOptionPane.showMessageDialog(null, m);

                m = new Mensagem("JOGADA");

                //m.setParam("op1", 2);
                //m.setParam("op2", 0);
                //testando as jogadas
                int op = Integer.parseInt(JOptionPane.showInputDialog(""
                        + "Id: "+p.getId()
                        + "\nVida: " + p.getVida() + ""
                        + "\nCura: " + p.getCura() + ""
                        + "\nAtaque: " + p.getAtaque() + ""
                        + "\nDefesa: " + p.getDefesa() + ""
                        + "\n\nInforme a ação desejada:" + p.getNome() + " "
                        + "\n 1 - Ataque"
                        + "\n 2 - Defesa"
                        + "\n 3 - Cura"));

                if (op == 1) {
                    m.setParam("acao", Acao.ATAQUE);
                } else if (op == 2) {
                    m.setParam("acao", Acao.DEFESA);
                } else if (op == 3) {
                    m.setParam("acao", Acao.CURA);
                }

                //envia os parametros que foram definidos através da variável m
                output.writeObject(m);
                output.flush(); //libera buffer para envio

                System.out.println("Mensagem " + m + " enviada.");

                m = (Mensagem) input.readObject();
                System.out.println("Resposta: " + m);

                p.setVida((Double) m.getParam("vidaJogador"));

                if (m.getOperacao().equals("SAIRREPLY") && (m.getStatus() == Status.WINNER || m.getStatus() == Status.LOOSER)) {
                    
                    if(Integer.parseInt(m.getParam("ganhador").toString()) == p.getId()){
                        JOptionPane.showMessageDialog(null, "Você ganhou");
                    }else{
                        JOptionPane.showMessageDialog(null, "Você perdeu");
                    }
                    
//                    if (m.getStatus() == Status.WINNER) {
//                        JOptionPane.showMessageDialog(null, "Você ganhou");
//                    } else {
//                        JOptionPane.showMessageDialog(null, "Você perdeu");
//                    }
                    sair = true;
                }

            }

            input.close();
            output.close();
            socket.close();

        } catch (IOException ex) {
            System.out.println("Erro no cliente: " + ex);
            Logger.getLogger(ClientRPG.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            System.out.println("Erro no cast: " + ex.getMessage());
            Logger.getLogger(ClientRPG.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
