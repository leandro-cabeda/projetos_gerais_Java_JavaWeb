package Adivinhador;

public enum Estados {
    CONECTADO, JOGANDO
}
